// PocketSign personal fork. AGPL-3.0. Uses SideStore's existing installation flow.
import SwiftUI
import UIKit

@MainActor
struct PocketSignStartView: View {
    let showApps: () -> Void
    let showSettings: () -> Void

    @State private var hasPairing = false
    @State private var hasAccount = false
    @State private var isChecking = false
    @State private var connectionReady = false
    @State private var connectionMessage = "Run the connection check after enabling LocalDevVPN."
    @State private var showingSetup = false
    @State private var showingTestConfirmation = false
    @State private var errorMessage: String?

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 12) {
                    Image(systemName: "iphone.and.arrow.forward")
                        .font(.system(size: 36, weight: .medium))
                        .foregroundStyle(Color.accentColor)
                    Text("Your first on-device install")
                        .font(.title2.bold())
                    Text("Use your free Apple account to sign and install Pocket Hello on this iPhone.")
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 12)
            }

            Section("1 · Prepare this iPhone") {
                statusRow("Pairing file", detail: hasPairing ? "Saved on this device" : "Import your own pairing file", ready: hasPairing)
                statusRow("Apple account", detail: hasAccount ? "Credentials saved; Apple will validate them during signing" : "Sign in during setup", ready: hasAccount)
                SwiftUI.Button("Open setup assistant") { showingSetup = true }
                SwiftUI.Button("Open LocalDevVPN") {
                    guard let url = URL(string: "localdevvpn://") else { return }
                    UIApplication.shared.open(url, options: [:]) { opened in
                        if !opened {
                            Task { @MainActor in
                                errorMessage = "Install LocalDevVPN from the App Store, then open it and enable the connection."
                            }
                        }
                    }
                }
            }

            Section("2 · Check the local connection") {
                Label(connectionMessage, systemImage: connectionReady ? "checkmark.circle.fill" : "network")
                    .foregroundStyle(connectionReady ? Color.green : Color.secondary)
                    .font(.subheadline)
                SwiftUI.Button {
                    Task { await checkConnection() }
                } label: {
                    HStack {
                        Text(isChecking ? "Checking…" : "Check connection")
                        Spacer()
                        if isChecking { ProgressView() }
                    }
                }
                .disabled(isChecking)
                Text("Use Wi-Fi with LocalDevVPN enabled. This check reaches device services; it does not validate your Apple password or sign an app.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("3 · Install one test app") {
                SwiftUI.Button {
                    showingTestConfirmation = true
                } label: {
                    Label("Install Pocket Hello", systemImage: "arrow.down.app")
                        .font(.headline)
                }
                .disabled(!hasPairing || !hasAccount)
                Text("Pocket Hello is bundled with this build. It has a local counter, no login, no network requests, and no permission prompts. You will review the installation before it starts.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                SwiftUI.Button("Open My Apps / import another IPA", action: showApps)
            }

            Section("Free account limits") {
                Label("Up to 3 active sideloaded apps", systemImage: "square.grid.3x1.below.line.grid.1x2")
                Text("PocketSign itself uses one slot. Pocket Hello uses a second. Existing sideloaded apps count toward the same device limit.")
                Label("Renew within 7 days", systemImage: "calendar.badge.clock")
                Text("Use My Apps to refresh both apps before they expire. If the signer expires or pairing breaks, computer access may be needed again.")
                Text("App IDs have a separate limit. This test app has no extensions and needs one App ID.")
            }
            .font(.subheadline)

            Section("About this test build") {
                Text("PocketSign is an independent personal fork of SideStore. Its Apple authentication, signing, and installation engine comes from SideStore. It is not an official SideStore release.")
                Text("Signing runs on your phone. Authentication and provisioning contact Apple. Upstream setup may also contact anisette infrastructure and source/update services. This is not an entirely offline app or a completed security audit.")
                SwiftUI.Button("Settings and signing details", action: showSettings)
            }
            .font(.footnote)
        }
        .navigationTitle("PocketSign")
        .onAppear(perform: refreshState)
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
            connectionReady = false
            connectionMessage = "Run the connection check after enabling LocalDevVPN."
            refreshState()
        }
        .sheet(isPresented: $showingSetup, onDismiss: refreshState) {
            OnboardingView(onFinish: {
                showingSetup = false
                refreshState()
            })
        }
        .alert("Install Pocket Hello?", isPresented: $showingTestConfirmation) {
            SwiftUI.Button("Continue") { importBundledTest() }
            SwiftUI.Button("Cancel", role: .cancel) { }
        } message: {
            Text("This will request an App ID and provisioning profile from Apple and use a free app slot. The normal installer will show any account or certificate prompts.")
        }
        .alert("PocketSign", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            SwiftUI.Button("OK", role: .cancel) { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "")
        }
    }

    private func statusRow(_ title: String, detail: String, ready: Bool) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: ready ? "checkmark.circle.fill" : "circle")
                .foregroundStyle(ready ? Color.green : Color.secondary)
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                Text(detail).font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    private func refreshState() {
        hasPairing = PairingFileManager.shared.hasPairingFile()
        hasAccount = AuthManager.shared.isAuthenticated
    }

    private func checkConnection() async {
        isChecking = true
        connectionReady = false
        defer { isChecking = false }
        refreshState()
        guard hasPairing else {
            connectionMessage = "Import your pairing file using the setup assistant."
            return
        }
        switch await isMinimuxerReady() {
        case .success(true):
            connectionReady = true
            connectionMessage = "Device services responded. You can try the test installation."
        case .success(false):
            connectionMessage = "Not ready. Check Wi-Fi, LocalDevVPN, and the pairing file."
        case .failure(let error):
            connectionMessage = "Connection failed: \(error.localizedDescription)"
        }
    }

    private func importBundledTest() {
        guard let original = Bundle.main.url(forResource: "PocketHello", withExtension: "ipa") else {
            errorMessage = "PocketHello.ipa is missing from this build. Rebuild with scripts/build.sh."
            return
        }
        do {
            // Hand a copy to the existing import flow; it may move or remove its input.
            let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            let copied = directory.appendingPathComponent("PocketHello.ipa")
            try FileManager.default.copyItem(at: original, to: copied)
            showApps()
            // The existing controller queues the import until its view appears.
            NotificationCenter.default.post(
                name: AppDelegate.importAppDeepLinkNotification,
                object: nil,
                userInfo: [AppDelegate.importAppDeepLinkURLKey: copied]
            )
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

# Validation record

Date: 24 October 2026. Environment: Linux, with no Xcode or connected iPhone.

## Completed

- Ten Python unit tests passed. They exercise source preparation, protection against overwritten output, upstream integrity, changed bundle/app-group identity, VPN callback identity, preservation of the SideBackup build symlink, IPA executable permissions, nested test-app packaging, and rejection of selected malformed archives and private setup data.
- The two new Swift files and the modified integration files passed tree-sitter Swift syntax parsing. This is a parser check, not an Apple SDK typecheck.
- The build shell script passed `bash -n`; Python scripts passed bytecode compilation; project and workflow YAML parsed successfully.
- A fresh download of the pinned upstream commit and recursive submodules reproduced the complete source inventory and hashes. The compact repository path therefore has a verified source-fetch step.
- The macOS build script was invoked and correctly stopped on Linux with a message requiring macOS/Xcode. It did not produce an IPA.

The IPA verifier's test inputs contain deliberately synthetic, temporary headers. They are unit-test fixtures, not compiled apps, and are not included as IPAs in this kit. Structural checks cannot establish that code launches or that it is safe.

## Still required

- Run the supplied macOS/Xcode workflow and resolve any compiler or dependency errors.
- Confirm both resulting packages contain compiled arm64 code and the signer contains the bundled test IPA. The workflow runs these structural checks before uploading artifacts.
- Install with a free Apple account; verify the custom signer's bootstrap metadata, pairing, and certificate configuration on the real device.
- Complete Apple sign-in and local connection checks.
- Install and launch Pocket Hello, preserve its counter across restart, refresh it, and check persistence again.
- Refresh and relaunch PocketSign itself. Test recovery before relying on it for other apps.

Until those steps pass, this is an unverified source build for a personal experiment. It is not a tested signer release, a guarantee of compatibility, or a security audit.

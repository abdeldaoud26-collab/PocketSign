import SwiftUI

@main
struct PocketHelloApp: App {
    var body: some Scene {
        WindowGroup { PocketHelloView() }
    }
}

struct PocketHelloView: View {
    @AppStorage("pocketHello.counter") private var count = 0

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.05, green: 0.10, blue: 0.19), Color(red: 0.07, green: 0.23, blue: 0.28)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            ScrollView {
                VStack(spacing: 24) {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 76))
                        .foregroundStyle(Color.mint)
                        .accessibilityHidden(true)
                    Text("Pocket Hello").font(.largeTitle.bold())
                    Text("Your test app opened.")
                        .font(.title3)
                        .foregroundStyle(.white.opacity(0.8))
                    Text("\(count)")
                        .font(.system(size: 76, weight: .bold, design: .rounded))
                        .monospacedDigit()
                        .accessibilityLabel("Counter: \(count)")
                    Button {
                        count += 1
                    } label: {
                        Text("Tap to test")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.mint)
                            .foregroundStyle(Color.black)
                            .clipShape(RoundedRectangle(cornerRadius: 18))
                    }
                    Button("Reset counter") { count = 0 }
                        .foregroundStyle(Color.mint)
                    Text("Close and reopen this app to check that the counter is saved. After refreshing it in PocketSign, check the counter again.")
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.white.opacity(0.75))
                    Text("This test app makes no network requests and asks for no personal-data permissions. It confirms launch and local storage—not a security audit of the signer.")
                        .font(.footnote)
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.white.opacity(0.6))
                }
                .padding(28)
                .padding(.top, 48)
                .frame(maxWidth: 540)
                .frame(maxWidth: .infinity)
            }
        }
        .preferredColorScheme(.dark)
        .foregroundStyle(.white)
    }
}

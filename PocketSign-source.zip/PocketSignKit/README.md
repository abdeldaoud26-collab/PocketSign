# PocketSign — personal iPhone signing experiment

**Status: source prepared; not compiled or tested on an iPhone. This ZIP does not contain an installable PocketSign IPA.** A macOS/Xcode build is the next required step. Do not rename the source ZIP to `.ipa`.

PocketSign is an independent, AI-assisted personal fork of [SideStore](https://github.com/SideStore/SideStore). It uses SideStore's existing Apple-account authentication, provisioning, signing, refresh, and local device installation engine. No paid certificate seller or paid Apple Developer membership is intended for the test.

## What is included

- A native iPhone Start screen with pairing/account status, a local connection check, and a button to install the bundled test app.
- **Pocket Hello**, a small native app with a counter saved on the phone. It has no network code, accounts, extensions, or personal-data permissions.
- The pinned SideStore source, its local dependencies, source-integrity checks, a preparation script, and a macOS build workflow.
- Packaging checks that reject missing executables, incorrect bundle IDs, missing test-app resources, and common accidentally included signing secrets.

This is a real source project using an existing installation engine. Successful compilation, first installation, authentication, self-refresh, and installation of the test app remain unverified. No claim of a completed security audit is made.

## Free account requirements

Apple's free provisioning limits still apply: up to three active sideloaded apps on a device, provisioning that expires after seven days, and a separate weekly App ID limit. PocketSign and Pocket Hello use two app slots. Existing sideloaded apps also count. Extensions can consume additional App IDs.

Normal on-device installation needs Wi-Fi, LocalDevVPN, and a valid pairing file for your own device. Initial installation and pairing normally need a trusted computer once. If you already have a working sideloader and valid pairing file, that may provide the bootstrap path; this fork has not been tested through that path. An expired signer or broken pairing may require computer access again.

The app runs on the iPhone after setup. Building its binary is a separate macOS/Xcode task. A free Apple account does not let a newly created app install itself from Safari with no existing signing or pairing setup.

## Build the two IPAs

### GitHub Actions

1. Create a GitHub repository for this project. A **public** repository can use GitHub's standard hosted macOS runners without build-minute charges. Private repositories have plan-specific allowances; do not enable paid overages just for this test.
2. Put the kit contents at the repository root, including `.github/workflows/build-ios.yml`. For a compact upload, omit only `upstream/SideStore/`; the workflow downloads the exact pinned source and verifies every file against the included manifest. Keep all the other files.
3. In **Actions**, run **Build PocketSign and test app**. Pushing to the `main` branch also starts the workflow.
4. After a successful run, download the **PocketSign-iPhone-test** artifact and unzip it. It should contain `PocketSign.ipa`, `PocketHello.ipa`, and `SHA256SUMS.txt`.

The workflow does not need an Apple password, P12, pairing file, device ID, or signing secret. Its output has placeholder/ad-hoc signatures and must still be signed for your device during installation. It does not publish an App Store release.

If a build fails, download **PocketSign-build-logs**. The workflow is prepared but has not run here, so compiler or dependency issues may still need fixes. No IPA should be considered available until this step succeeds.

### Mac with Xcode

Use Xcode 26.4 with its iOS SDK, matching the pinned upstream CI. Select that Xcode installation, install `xcodegen` and `ldid` with Homebrew, then run from the kit root:

```bash
python3 scripts/fetch_upstream.py
python3 -m unittest discover -s tests -v
bash scripts/build.sh
```

The build uses a fresh `build/SideStore` directory and refuses to overwrite one. Before rebuilding, move that generated directory or use a fresh checkout. Keep any useful logs. If ZIP extraction lost the snapshot's symlinks, use a clean compact copy without the `upstream/SideStore` directory and run `fetch_upstream.py`.

## Install and test, after a successful build

The steps below are the intended validation procedure, **not a report of a completed device test**.

1. Check that enough free app slots and App IDs remain. Install [LocalDevVPN](https://apps.apple.com/app/localdevvpn/id6755608044) from the App Store.
2. Install `PocketSign.ipa` with a working sideloader using your free Apple account. On a computer, [iLoader](https://github.com/nab138/iloader) supports importing a local IPA. Its automatic SideStore pairing/certificate setup may not recognize this custom bundle ID; manual setup and troubleshooting may be necessary. Do not select the official SideStore download expecting it to install PocketSign.
3. Trust your developer app in Settings and enable Developer Mode if iOS requests it. Open PocketSign, import your own valid pairing file through the setup assistant, and sign in with the same Apple account used for installation. Review any certificate-replacement prompt: replacing a development certificate can affect other apps signed with it.
4. Enable LocalDevVPN, connect to Wi-Fi, and run **Check connection**. This checks local device communication, not Apple authentication.
5. Tap **Install Pocket Hello**, review the normal installation prompt, and let the signing/installation process finish. Record the full error if it fails; the UI must not be treated as proof of success.
6. Open **Pocket Hello** from the iPhone Home Screen. Tap the counter to 3, close the app, and reopen it. The value should still be 3.
7. In PocketSign's **My Apps**, refresh Pocket Hello. Reopen it and check that the value remains 3. Then refresh PocketSign itself and check that it launches again. This last step is an essential acceptance test for the custom bundle identity and bootstrap configuration.

Refresh before seven days expire. Keep the built IPAs for recovery. Do not assume that every arbitrary IPA is compatible: paid-only entitlements, encrypted App Store binaries, unsupported OS versions, and app-specific protections can prevent installation or operation.

## Privacy and account handling

The signing flow remains SideStore's, including its credential handling and network dependencies. It communicates with Apple and may use upstream anisette, app-source, and update services. This is not an offline signer. The personal label does not itself make the code or an imported IPA safe.

Never put your Apple password, two-factor code, P12/private key, or pairing file in this repository or in a chat message. A pairing file grants access to device services and must be kept private. No such personal data is included in this kit. The test app's lack of network access does not prove the signer is secure.

If Apple login or two-factor authentication already fails in SideStore, this fork may encounter the same problem. It does not bypass Apple's authentication or free-account restrictions.

## Implementation and provenance

- Source revision and dependency commits: `upstream.lock.json`.
- Source integrity inventory: `upstream-files.sha256.json`.
- Personal changes: `app-overlay/` and `scripts/prepare.py`; the bundled upstream snapshot remains unchanged.
- Base signer identity: `org.pocketsign.SideStore`; test identity: `org.pocketsign.hello`. The bootstrap signer may add your team identifier.
- General import URL scheme: `pocketsign://`. Upstream internal self-refresh callback conventions are preserved.
- Retained upstream labels and assets are attributed to SideStore; PocketSign is not an official release or endorsement. Do not submit this package as an upstream contribution without following the project's contribution rules.
- License: AGPL-3.0 as in the included `LICENSE`, with upstream and dependency notices retained. New code and modifications are offered under the same license. Corresponding source accompanies this kit.

See `docs/VALIDATION.md` for what was and was not checked.

## Primary references

Checked on 24 October 2026:

- [Apple developer account overview](https://developer.apple.com/help/account/basics/about-your-developer-account/)
- [SideStore installation prerequisites](https://docs.sidestore.io/docs/installation/prerequisites)
- [SideStore installation](https://docs.sidestore.io/docs/installation/install)
- [SideStore FAQ](https://docs.sidestore.io/docs/faq)
- [iLoader source and instructions](https://github.com/nab138/iloader)
- [GitHub Actions billing and usage](https://docs.github.com/en/actions/concepts/billing-and-usage)

"""Exercise preparation and reject malformed packages; no device tests here."""
import io
import json
import os
from pathlib import Path
import plistlib
import shutil
import stat
import struct
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from prepare import prepare, verify_snapshot
from package import package
from verify_ipa import check


class SourcePreparationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory()
        cls.output = Path(cls.temporary.name) / "prepared"
        prepare(ROOT / "upstream/SideStore", cls.output)

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def test_upstream_unchanged_and_fork_identity_consistent(self):
        verify_snapshot(ROOT / "upstream/SideStore")
        info = plistlib.loads((self.output / "AltStore/Info.plist").read_bytes())
        self.assertEqual(info["CFBundleDisplayName"], "PocketSign")
        self.assertEqual(info["CFBundleURLTypes"][0]["CFBundleURLSchemes"], ["pocketsign"])
        entitlements = plistlib.loads((self.output / "AltStore/Resources/ReleaseEntitlements.plist").read_bytes())
        self.assertEqual(entitlements["application-identifier"], "XYZ0123456.org.pocketsign.SideStore")
        self.assertEqual(entitlements["com.apple.security.application-groups"], ["group.org.pocketsign.SideStore"])
        self.assertNotIn("aps-environment", entitlements)
        self.assertNotIn("com.apple.developer.siri", entitlements)
        shared = (self.output / "Shared/Extensions/Bundle+AltStore.swift").read_text()
        self.assertNotIn("com.SideStore.SideStore", shared)
        self.assertIn('appbundleIdentifier = "org.pocketsign.SideStore"', shared)
        callback = (self.output / "SideStore/Views/Onboarding/OnboardingView.swift").read_text()
        self.assertIn("localdevvpn://enable?scheme=pocketsign", callback)

    def test_build_dependency_symlink_is_preserved(self):
        link = self.output / "AltStore/Resources/SideBackup.ipa"
        self.assertTrue(link.is_symlink())
        self.assertEqual(os.readlink(link), "../../build/SideBackup.ipa")

    def test_existing_output_is_not_overwritten(self):
        sentinel = self.output / "keep.txt"
        sentinel.write_text("keep")
        with self.assertRaisesRegex(ValueError, "already exists"):
            prepare(ROOT / "upstream/SideStore", self.output)
        self.assertEqual(sentinel.read_text(), "keep")

    def test_modified_snapshot_is_rejected_before_patching(self):
        with tempfile.TemporaryDirectory() as directory:
            altered = Path(directory) / "altered"
            shutil.copytree(ROOT / "upstream/SideStore", altered, symlinks=True)
            (altered / "Build.xcconfig").write_text("modified")
            with self.assertRaisesRegex(ValueError, "integrity check failed"):
                prepare(altered, Path(directory) / "result")
            self.assertFalse((Path(directory) / "result").exists())


class IPAVerificationTests(unittest.TestCase):
    # Intentionally synthetic header used ONLY in temporary unit-test fixtures.
    # This is not a compiled or installable app and is never distributed.
    binary = (struct.pack("<8I", 0xFEEDFACF, 0x0100000C, 0, 2, 1, 24, 0, 0)
              + struct.pack("<6I", 0x32, 24, 2, 0xF0000, 0x1A0400, 0))

    def make_fixture(self, identifier="org.pocketsign.hello", binary=None, extra=None, mode=0o755, plist_extra=None):
        output = io.BytesIO()
        info = {"CFBundleIdentifier": identifier, "CFBundleExecutable": "Fixture"}
        info.update(plist_extra or {})
        with zipfile.ZipFile(output, "w") as archive:
            archive.writestr("Payload/Fixture.app/Info.plist", plistlib.dumps(info))
            executable = zipfile.ZipInfo("Payload/Fixture.app/Fixture")
            executable.create_system = 3
            executable.external_attr = (stat.S_IFREG | mode) << 16
            archive.writestr(executable, self.binary if binary is None else binary)
            for name, data in (extra or {}).items():
                archive.writestr(name, data)
        output.seek(0)
        return output

    def test_nested_test_app_is_required_and_checked(self):
        nested = self.make_fixture().getvalue()
        signer = self.make_fixture("org.pocketsign.SideStore", extra={"Payload/Fixture.app/PocketHello.ipa": nested})
        result = check(signer, "org.pocketsign.SideStore", require_test=True)
        self.assertEqual(result["device_test"], "not performed")
        with self.assertRaises(KeyError):
            check(self.make_fixture("org.pocketsign.SideStore"), "org.pocketsign.SideStore", require_test=True)

    def test_text_or_wrong_architecture_is_rejected(self):
        for binary in [b"not a compiled app", struct.pack("<IIIIIIII", 0xFEEDFACF, 0x01000007, 0, 2, 0, 0, 0, 0)]:
            with self.subTest(binary=binary), self.assertRaises(ValueError):
                check(self.make_fixture(binary=binary), "org.pocketsign.hello")

    def test_arm64_simulator_and_missing_platform_are_rejected(self):
        simulator = bytearray(self.binary)
        struct.pack_into("<I", simulator, 40, 7)
        missing = struct.pack("<8I", 0xFEEDFACF, 0x0100000C, 0, 2, 0, 0, 0, 0)
        for binary in (simulator, missing):
            with self.subTest(binary=binary), self.assertRaisesRegex(ValueError, "iOS-device platform"):
                check(self.make_fixture(binary=binary), "org.pocketsign.hello")

    def test_legacy_device_platform_is_accepted(self):
        binary = (struct.pack("<8I", 0xFEEDFACF, 0x0100000C, 0, 2, 1, 16, 0, 0)
                  + struct.pack("<4I", 0x25, 16, 0xF0000, 0xF0000))
        check(self.make_fixture(binary=binary), "org.pocketsign.hello")

    def test_universal_binary_slices_are_checked(self):
        for magic, entry in (
            (0xCAFEBABE, struct.pack(">5I", 0x0100000C, 0, 64, len(self.binary), 4)),
            (0xCAFEBABF, struct.pack(">2I2Q2I", 0x0100000C, 0, 64, len(self.binary), 4, 0)),
        ):
            header = struct.pack(">2I", magic, 1) + entry
            binary = header + bytes(64 - len(header)) + self.binary
            check(self.make_fixture(binary=binary), "org.pocketsign.hello")
            simulator = bytearray(binary)
            struct.pack_into("<I", simulator, 64 + 40, 7)
            with self.subTest(magic=magic), self.assertRaisesRegex(ValueError, "iOS-device platform"):
                check(self.make_fixture(binary=simulator), "org.pocketsign.hello")
            with self.assertRaisesRegex(ValueError, "slice bounds"):
                check(self.make_fixture(binary=binary[:-1]), "org.pocketsign.hello")

    def test_malformed_load_commands_and_nonexecutables_are_rejected(self):
        variants = []
        for offset, value in ((12, 6), (16, 2), (36, 0), (36, 32), (52, 1)):
            altered = bytearray(self.binary)
            struct.pack_into("<I", altered, offset, value)
            variants.append(altered)
        variants.append(self.binary[:-1])
        for binary in variants:
            with self.subTest(binary=binary), self.assertRaises(ValueError):
                check(self.make_fixture(binary=binary), "org.pocketsign.hello")

    def test_wrong_identity_and_nonexecutable_file_are_rejected(self):
        with self.assertRaisesRegex(ValueError, "bundle identifier"):
            check(self.make_fixture(), "org.wrong.app")
        with self.assertRaisesRegex(ValueError, "permissions"):
            check(self.make_fixture(mode=0o644), "org.pocketsign.hello")

    def test_private_setup_data_is_rejected(self):
        for extra in [{"Payload/Fixture.app/private.p12": b"secret"}, {"Payload/Fixture.app/device.mobiledevicepairing": b"secret"}]:
            with self.subTest(extra=extra), self.assertRaisesRegex(ValueError, "credentials"):
                check(self.make_fixture(extra=extra), "org.pocketsign.hello")
        with self.assertRaisesRegex(ValueError, "private setup field"):
            check(self.make_fixture(plist_extra={"ALTDeviceID": "private"}), "org.pocketsign.hello")

    def test_test_app_permissions_and_archive_traversal_are_rejected(self):
        with self.assertRaisesRegex(ValueError, "privacy permissions"):
            check(self.make_fixture(plist_extra={"NSCameraUsageDescription": "unexpected"}), "org.pocketsign.hello", test_app=True)
        with self.assertRaisesRegex(ValueError, "Unsafe archive path"):
            check(self.make_fixture(extra={"../outside": b"bad"}), "org.pocketsign.hello")

    def test_packager_preserves_executable_permissions_and_links(self):
        with tempfile.TemporaryDirectory() as directory:
            app = Path(directory) / "Fixture.app"
            app.mkdir()
            (app / "Info.plist").write_bytes(plistlib.dumps({"CFBundleIdentifier": "org.pocketsign.hello", "CFBundleExecutable": "Fixture"}))
            executable = app / "Fixture"
            executable.write_bytes(self.binary)
            executable.chmod(0o755)
            (app / "link").symlink_to("Fixture")
            output = Path(directory) / "fixture.ipa"
            package(app, output)
            check(output, "org.pocketsign.hello", test_app=True)
            with zipfile.ZipFile(output) as archive:
                link = archive.getinfo("Payload/Fixture.app/link")
                self.assertTrue(stat.S_ISLNK(link.external_attr >> 16))
                self.assertEqual(archive.read(link), b"Fixture")


if __name__ == "__main__":
    unittest.main()

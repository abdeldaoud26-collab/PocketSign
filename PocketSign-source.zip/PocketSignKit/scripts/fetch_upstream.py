#!/usr/bin/env python3
"""Fetch the exact published sources if using a compact copy of this kit."""
import json
import shutil
import subprocess
import tempfile
from pathlib import Path

from prepare import ROOT, verify_snapshot


def fetch():
    destination = ROOT / "upstream/SideStore"
    if destination.exists():
        verify_snapshot(destination)
        print("Pinned source snapshot verified; no download needed.")
        return
    lock = json.loads((ROOT / "upstream.lock.json").read_text())
    with tempfile.TemporaryDirectory(prefix="pocketsign-source-") as directory:
        checkout = Path(directory) / "SideStore"
        subprocess.run(["git", "clone", "--filter=blob:none", "--no-checkout", lock["upstream"], str(checkout)], check=True)
        subprocess.run(["git", "checkout", "--detach", lock["revision"]], cwd=checkout, check=True)
        subprocess.run(["git", "submodule", "update", "--init", "--recursive"], cwd=checkout, check=True)
        staged = Path(directory) / "snapshot"
        shutil.copytree(checkout, staged, symlinks=True,
                        ignore=shutil.ignore_patterns(".git", ".DS_Store", "__pycache__"))
        verify_snapshot(staged)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(staged), destination)
    print("Pinned source downloaded and verified.")


if __name__ == "__main__":
    fetch()

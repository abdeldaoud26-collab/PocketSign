#!/bin/bash
# Build both iPhone apps. Never takes Apple credentials, a P12, or a pairing file.
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"
if [[ "$(uname -s)" != Darwin ]]; then
    echo "This build requires macOS and Xcode. Use the included GitHub Actions workflow." >&2
    exit 2
fi
for tool in xcodebuild xcodegen ldid python3; do
    command -v "$tool" >/dev/null || { echo "Missing build tool: $tool" >&2; exit 2; }
done
if [[ -e build/SideStore ]]; then
    echo "build/SideStore already exists. Use a clean checkout or move the existing build directory." >&2
    exit 2
fi
mkdir -p build dist
python3 scripts/prepare.py

# Build the small test application first so it can be bundled in the signer.
xcodegen generate --spec PocketHello/project.yml
xcodebuild -project PocketHello/PocketHello.xcodeproj -scheme PocketHello \
    -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
    -derivedDataPath "$ROOT_DIR/build/HelloDerivedData" \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build \
    >build/hello-build.log 2>&1 || { tail -n 100 build/hello-build.log; exit 1; }
HELLO_APP="$ROOT_DIR/build/HelloDerivedData/Build/Products/Release-iphoneos/PocketHello.app"
ldid -S "$HELLO_APP/PocketHello"
python3 scripts/package.py "$HELLO_APP" dist/PocketHello.ipa
cp dist/PocketHello.ipa build/SideStore/AltStore/Resources/PocketHello.ipa

# Preserve SideStore's own build layout and dependency ordering.
(
    cd build/SideStore
    xcodebuild archive -project AltStore.xcodeproj -scheme SideStore \
        -sdk iphoneos -configuration Release -destination 'generic/platform=iOS' \
        -archivePath SideStore.xcarchive \
        -onlyUsePackageVersionsFromResolvedFile -disableAutomaticPackageResolution \
        CODE_SIGNING_REQUIRED=NO CODE_SIGNING_ALLOWED=NO AD_HOC_CODE_SIGNING_ALLOWED=YES \
        DEVELOPMENT_TEAM=XYZ0123456 ORG_IDENTIFIER=org.pocketsign \
        MARKETING_VERSION=0.1.0 CURRENT_PROJECT_VERSION=1
    make fakesign ipa
) >build/signer-build.log 2>&1 || { tail -n 120 build/signer-build.log; exit 1; }
cp build/SideStore/SideStore.ipa dist/PocketSign.ipa
python3 scripts/verify_ipa.py dist/PocketSign.ipa --bundle-id org.pocketsign.SideStore --require-test
python3 scripts/verify_ipa.py dist/PocketHello.ipa --bundle-id org.pocketsign.hello --test-app
python3 - <<'PY'
from pathlib import Path
from hashlib import sha256
folder=Path('dist')
with (folder/'SHA256SUMS.txt').open('w') as out:
    for p in sorted(folder.glob('*.ipa')):
        out.write(f'{sha256(p.read_bytes()).hexdigest()}  {p.name}\n')
print('Packaged PocketSign.ipa and PocketHello.ipa. They still need your Apple-account signature.')
PY

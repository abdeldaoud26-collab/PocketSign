#!/usr/bin/env python3
"""Structural IPA checks; these do not prove launch, signing trust, or safety."""
import argparse
import io
import plistlib
import struct
import zipfile
from pathlib import Path, PurePosixPath


def validate_device_binary(binary):
    """Require an arm64 iOS-device executable, including every universal slice."""
    if len(binary) < 32:
        raise ValueError("Missing or truncated Mach-O executable")
    magic = struct.unpack_from(">I", binary)[0]
    if magic in (0xCAFEBABE, 0xCAFEBABF):
        count = struct.unpack_from(">I", binary, 4)[0]
        entry_size = 32 if magic == 0xCAFEBABF else 20
        table_end = 8 + count * entry_size
        if not 0 < count <= 32 or table_end > len(binary):
            raise ValueError("Invalid universal Mach-O header")
        ranges = []
        for index in range(count):
            position = 8 + index * entry_size
            cpu = struct.unpack_from(">I", binary, position)[0]
            offset, length = struct.unpack_from(">QQ" if entry_size == 32 else ">II", binary, position + 8)
            if cpu != 0x0100000C:
                raise ValueError("Expected an arm64 iPhone executable")
            if offset < table_end or length < 32 or offset + length > len(binary):
                raise ValueError("Invalid universal Mach-O slice bounds")
            if any(offset < end and offset + length > start for start, end in ranges):
                raise ValueError("Overlapping universal Mach-O slices")
            ranges.append((offset, offset + length))
            _validate_device_slice(binary[offset:offset + length])
    else:
        _validate_device_slice(binary)


def _validate_device_slice(binary):
    if len(binary) < 32 or binary[:4] != b'\xcf\xfa\xed\xfe':
        raise ValueError("Missing compiled 64-bit Mach-O executable")
    _, cpu, _, file_type, count, commands_size, _, _ = struct.unpack_from("<8I", binary)
    if cpu != 0x0100000C:
        raise ValueError("Expected an arm64 iPhone executable")
    if file_type != 2:
        raise ValueError("Mach-O is not an application executable")
    end = 32 + commands_size
    if end > len(binary) or count > commands_size // 8:
        raise ValueError("Truncated Mach-O load commands")
    offset = 32
    platforms, legacy_platforms = [], []
    for _ in range(count):
        if offset + 8 > end:
            raise ValueError("Truncated Mach-O load command")
        command, length = struct.unpack_from("<II", binary, offset)
        if length < 8 or length % 8 or offset + length > end:
            raise ValueError("Invalid Mach-O load command length")
        if command == 0x32:  # LC_BUILD_VERSION: platform 2 = iOS, 7 = simulator.
            if length < 24:
                raise ValueError("Truncated LC_BUILD_VERSION")
            platform, _, _, tools = struct.unpack_from("<4I", binary, offset + 8)
            if length != 24 + tools * 8:
                raise ValueError("Invalid LC_BUILD_VERSION tool table")
            platforms.append(platform)
        elif command in (0x24, 0x25, 0x2F, 0x30):
            if length != 16:
                raise ValueError("Invalid legacy platform load command")
            legacy_platforms.append(command)
        offset += length
    if offset != end:
        raise ValueError("Mach-O load command size mismatch")
    # Older arm64 device binaries may use LC_VERSION_MIN_IPHONEOS instead.
    valid_modern = platforms == [2] and legacy_platforms in ([], [0x25])
    valid_legacy = not platforms and legacy_platforms == [0x25]
    if not (valid_modern or valid_legacy):
        raise ValueError("Expected iOS-device platform 2 or LC_VERSION_MIN_IPHONEOS; simulator binaries are not installable")


def check(ipa, expected_id, require_test=False, test_app=False):
    with zipfile.ZipFile(ipa) as archive:
        names=archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate paths in IPA")
        if any(PurePosixPath(n).is_absolute() or ".." in PurePosixPath(n).parts for n in names):
            raise ValueError("Unsafe archive path")
        mains=[n for n in names if len(PurePosixPath(n).parts)==3 and n.startswith("Payload/") and n.endswith(".app/Info.plist")]
        if len(mains)!=1:
            raise ValueError("Expected one main app Info.plist")
        plist=plistlib.loads(archive.read(mains[0]))
        if plist.get("CFBundleIdentifier") != expected_id:
            raise ValueError("Unexpected bundle identifier")
        app_root=mains[0][:-len("Info.plist")]
        executable=plist.get("CFBundleExecutable", "")
        if not executable or "/" in executable:
            raise ValueError("Missing or invalid executable name")
        executable_path=app_root+executable
        binary=archive.read(executable_path)
        validate_device_binary(binary)
        if not ((archive.getinfo(executable_path).external_attr>>16)&0o111):
            raise ValueError("Executable permissions are missing")
        for forbidden in ["ALTDeviceID", "ALTPairingFile", "AppleIDPassword", "password"]:
            if forbidden in plist:
                raise ValueError(f"Distribution IPA contains private setup field: {forbidden}")
        secrets=[n for n in names if n.lower().endswith(('.p12','.mobiledevicepairing','.p8'))]
        if secrets:
            raise ValueError("Signing credentials or a pairing file are included")
        if require_test:
            nested=archive.read(app_root+"PocketHello.ipa")
            check(io.BytesIO(nested),'org.pocketsign.hello',test_app=True)
        if test_app:
            if any(k.startswith('NS') and k.endswith('UsageDescription') for k in plist):
                raise ValueError("Test app unexpectedly requests privacy permissions")
            if any('/PlugIns/' in n for n in names):
                raise ValueError("Test app should not contain extensions")
    return {"bundle_id":expected_id,"structural_checks":"passed","device_test":"not performed"}


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('ipa',type=Path)
    parser.add_argument('--bundle-id',required=True)
    parser.add_argument('--require-test',action='store_true')
    parser.add_argument('--test-app',action='store_true')
    args=parser.parse_args()
    print(check(args.ipa,args.bundle_id,args.require_test,args.test_app))

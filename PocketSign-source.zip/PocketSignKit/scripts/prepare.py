#!/usr/bin/env python3
"""Materialize a personal SideStore fork without changing the pinned source snapshot."""
import argparse
import hashlib
import json
import os
import plistlib
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OLD_ID = "com.SideStore.SideStore"
NEW_ID = "org.pocketsign.SideStore"


def replace_once(path, old, new):
    text = path.read_text()
    if text.count(old) != 1:
        raise ValueError(f"Unexpected upstream content in {path.name}; refusing an ambiguous patch")
    path.write_text(text.replace(old, new))


def verify_snapshot(source):
    manifest = json.loads((ROOT / "upstream-files.sha256.json").read_text())
    for name, expected in manifest.items():
        file = source / name
        content = ("SYMLINK:" + os.readlink(file)).encode() if file.is_symlink() else file.read_bytes() if file.is_file() else b""
        if hashlib.sha256(content).hexdigest() != expected:
            raise ValueError(f"Pinned source integrity check failed: {name}")
    actual = {p.relative_to(source).as_posix() for p in source.rglob("*") if p.is_file() or p.is_symlink()}
    if actual != set(manifest):
        raise ValueError("Pinned source contains unexpected files")


def prepare(source, destination):
    source = source.resolve()
    destination = destination.resolve()
    verify_snapshot(source)
    if source == destination or source in destination.parents or destination in source.parents:
        raise ValueError("Source and output directories must not overlap")
    if destination.exists():
        raise ValueError("Output already exists. Choose a fresh output directory; no files were removed.")
    shutil.copytree(source, destination, symlinks=True)

    # This is an independent fork, not an upstream contribution. Keep attribution.
    for tree in ["AltStore", "AltWidget", "SideBackup", "SideStore", "Shared", "xcconfigs"]:
        for path in (destination / tree).rglob("*"):
            if path.is_file() and path.suffix in {".swift", ".plist", ".entitlements", ".xcconfig"}:
                text = path.read_text()
                if OLD_ID in text:
                    path.write_text(text.replace(OLD_ID, NEW_ID))
    replace_once(destination / "Build.xcconfig", "ORG_IDENTIFIER = com.SideStore", "ORG_IDENTIFIER = org.pocketsign")
    replace_once(destination / "Makefile", "ORG_IDENTIFIER=com.SideStore", "ORG_IDENTIFIER=org.pocketsign")

    info_path = destination / "AltStore/Info.plist"
    info = plistlib.loads(info_path.read_bytes())
    info["CFBundleDisplayName"] = "PocketSign"
    info["PocketSignUpstreamRevision"] = json.loads((ROOT / "upstream.lock.json").read_text())["revision"]
    # Preserve the upstream per-bundle callback used for self-refresh; avoid taking
    # over the official application's general sidestore:// import scheme.
    info["CFBundleURLTypes"][0]["CFBundleURLName"] = "PocketSign General"
    info["CFBundleURLTypes"][0]["CFBundleURLSchemes"] = ["pocketsign"]
    info_path.write_bytes(plistlib.dumps(info, sort_keys=False))

    # Update the corresponding URL-handler branch, if it uses the literal scheme.
    candidates = list((destination / "SideStore").rglob("URLHandler.swift"))
    if not candidates:
        candidates = list((destination / "AltStore").rglob("URLHandler.swift"))
    for path in candidates:
        text = path.read_text()
        text = text.replace('case "sidestore":', 'case "pocketsign":')
        text = text.replace('url.scheme == "sidestore"', 'url.scheme == "pocketsign"')
        path.write_text(text)

    # Return from the local VPN app to this fork, including when official
    # SideStore is installed alongside it.
    replace_once(destination / "SideStore/Views/Onboarding/OnboardingView.swift",
                 "localdevvpn://enable?scheme=sidestore", "localdevvpn://enable?scheme=pocketsign")

    model = destination / "AltStore/Core/Model/StoreApp.swift"
    replace_once(model, 'app.name = "SideStore"', 'app.name = "PocketSign"')
    replace_once(model, 'app.developerName = "Side Team"', 'app.developerName = "Personal fork · SideStore engine"')
    replace_once(model, 'app.localizedDescription = "SideStore is an alternative App Store."',
                 'app.localizedDescription = "Personal on-device signing test based on SideStore."')

    # Existing indices for Sources, Browse, My Apps, and Settings remain unchanged.
    tab = destination / "AltStore/TabBarController.swift"
    replace_once(tab, "@preconcurrency import UIKit", "@preconcurrency import UIKit\nimport SwiftUI")
    anchor = "        self.sourcesViewController = sourcesNavigationController.viewControllers.first as? SourcesViewController"
    addition = '''

        // PocketSign personal start screen. Device installation needs proper testing.
        let start = PocketSignStartView(
            showApps: { [weak self] in self?.selectedIndex = Tab.myApps.rawValue },
            showSettings: { [weak self] in self?.selectedIndex = Tab.settings.rawValue }
        )
        let host = UIHostingController(rootView: start)
        let navigation = UINavigationController(rootViewController: host)
        navigation.tabBarItem = UITabBarItem(title: "Start", image: UIImage(systemName: "checkmark.seal"), tag: 0)
        var tabs = self.viewControllers ?? []
        tabs[Tab.news.rawValue] = navigation
        self.viewControllers = tabs
        self.selectedIndex = Tab.news.rawValue
'''
    replace_once(tab, anchor, anchor + addition)
    shutil.copy2(ROOT / "app-overlay/PocketSignStartView.swift", destination / "AltStore/PocketSignStartView.swift")

    # Free-account package: keep required app groups, avoid unnecessary paid
    # capability requests in the placeholder signatures used by the bootstrap tool.
    entitlements_path = destination / "AltStore/Resources/ReleaseEntitlements.plist"
    entitlements = plistlib.loads(entitlements_path.read_bytes())
    for key in ["aps-environment", "com.apple.developer.siri"]:
        entitlements.pop(key, None)
    entitlements_path.write_bytes(plistlib.dumps(entitlements, sort_keys=False))

    (destination / "POCKETSIGN_BUILD.json").write_text(json.dumps({
        "name": "PocketSign", "version": "0.1.0", "base_bundle_id": NEW_ID,
        "upstream": json.loads((ROOT / "upstream.lock.json").read_text()),
        "status": "Source prepared. Xcode compilation and physical-device tests required."
    }, indent=2) + "\n")
    return destination


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=ROOT / "upstream/SideStore")
    parser.add_argument("--output", type=Path, default=ROOT / "build/SideStore")
    args = parser.parse_args()
    try:
        print(prepare(args.source, args.output))
    except (ValueError, OSError) as error:
        parser.exit(1, str(error) + "\n")

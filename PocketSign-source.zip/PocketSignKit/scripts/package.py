#!/usr/bin/env python3
"""Package a compiled .app as an IPA, preserving executable permissions."""
import argparse
import os
import stat
import zipfile
from pathlib import Path


def package(app, output):
    app = Path(app)
    output = Path(output)
    if not app.is_dir() or app.suffix != ".app":
        raise ValueError("Expected a compiled .app directory")
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(app.rglob("*")):
            relative = "Payload/" + app.name + "/" + path.relative_to(app).as_posix()
            if path.is_symlink():
                info = zipfile.ZipInfo(relative)
                info.create_system = 3
                info.external_attr = (stat.S_IFLNK | 0o777) << 16
                archive.writestr(info, os.readlink(path))
            elif path.is_file():
                archive.write(path, relative)


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("app", type=Path)
    parser.add_argument("output", type=Path)
    args=parser.parse_args()
    package(args.app, args.output)
